'use strict'
module.exports = {
  NODE_ENV: '"production"',
  baseUrl: '""',
  appId: '"1580387213331704"',
  aesKey: '"S9u978Q31NGPGc5H"',
  ivKey: '"X83yESM9iShLxfwS"',
  appKey: '"Sd6qkHm9o4LaVluYRX5pUFyNuiu2a8oi"',
}
