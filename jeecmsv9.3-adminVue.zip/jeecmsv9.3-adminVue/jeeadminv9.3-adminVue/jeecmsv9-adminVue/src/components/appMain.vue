<template>
<div >
       <router-view></router-view>
</div>

 
</template>

<script>
export default {
     name:'app-main',
}
</script>

<style scoped >

</style>
