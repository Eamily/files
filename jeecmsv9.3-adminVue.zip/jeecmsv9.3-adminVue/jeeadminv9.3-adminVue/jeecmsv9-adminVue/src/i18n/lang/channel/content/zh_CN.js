'use strict';
export default {
      content:{
          label:{
             currentChannel:'当前栏目',
              contentAdd:'内容发布',
              solidTop:'固顶',
              recommend:'推荐',
              type:'类型',
              clickCount: '点击',
              releaseTime:'发布时间',
              state:'状态',
          }
      }
}