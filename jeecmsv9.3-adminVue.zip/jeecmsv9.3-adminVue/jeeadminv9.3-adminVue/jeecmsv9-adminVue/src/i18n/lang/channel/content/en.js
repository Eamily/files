'use strict';
export default {
    content: {
        label: {
            currentChannel: 'Current Channel',
            contentAdd: 'Content Add', 
            solidTop: 'Top',
            recommend: 'recommend',
            type: 'Type',
            clickCount:'ClickCount',
            releaseTime: 'ReleaseTime',
            state: 'state',}
    }
}